import numpy as np
import scipy as sp
import matplotlib
import pandas as pd
import sklearn
import sys

print(f"""Current python version is {sys.version}
Current numpy version is {np.__version__}
Current scipy version is {sp.__version__}
Current matplotlib version is {matplotlib.__version__}
Current pandas version is {pd.__version__}
Current sklearn version is {sklearn.__version__}""")

print("Hello, World!")
